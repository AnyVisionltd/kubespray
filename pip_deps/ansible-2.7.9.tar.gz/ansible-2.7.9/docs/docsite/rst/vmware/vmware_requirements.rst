.. _vmware_requirements:

********************
VMware Prerequisites
********************

This is what you'll need to get started...
